import * as mutTypes from '../mutation-types.js'

const state = {
  
}

const actions = {
  
}

const mutations = {
  
}

const getters = {
}

export default {
  getters,
  state,
  actions,
  mutations
}
